package com.simibubi.create.compat.trainmap;

import java.util.List;
import com.mojang.blaze3d.platform.Window;
import com.mojang.blaze3d.vertex.PoseStack;
import com.simibubi.create.foundation.gui.RemovedGuiUtils;
import com.simibubi.create.foundation.utility.CreateLang;
import com.simibubi.create.infrastructure.config.AllConfigs;

import journeymap.client.api.display.Context.UI;
import journeymap.client.api.util.UIState;
import journeymap.client.ui.fullscreen.Fullscreen;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.client.renderer.Rect2i;
import net.minecraft.network.chat.FormattedText;
import net.minecraft.util.Mth;

public class JourneyTrainMap {

	private static boolean requesting;

	public static void tick() {
		if (!AllConfigs.client().showTrainMapOverlay.get() || !(Minecraft.getInstance().screen instanceof Fullscreen)) {
			if (requesting)
				TrainMapSyncClient.stopRequesting();
			requesting = false;
			return;
		}
		TrainMapManager.tick();
		requesting = true;
		TrainMapSyncClient.requestData();
	}

	public static boolean mouseClick(Screen screen, int mouseX, int mouseY) {
		if (!(screen instanceof Fullscreen))
			return false;

		return TrainMapManager.handleToggleWidgetClick(mouseX, mouseY, 3, 30);
	}

	// Called by JourneyFullscreenMapMixin
	public static void onRender(GuiGraphics graphics, Fullscreen screen, double x, double z, int mX, int mY, float pt) {
		UIState state = screen.getUiState();
		if (state == null)
			return;
		if (state.ui != UI.Fullscreen)
			return;
		if (!state.active)
			return;
		if (!AllConfigs.client().showTrainMapOverlay.get()) {
			renderToggleWidgetAndTooltip(graphics, screen, mX, mY);
			return;
		}

		Minecraft mc = Minecraft.getInstance();
		Window window = mc.getWindow();

		double guiScale = (double) window.getScreenWidth() / window.getGuiScaledWidth();
		double scale = state.blockSize / guiScale;

		PoseStack pose = graphics.pose();
		pose.pushPose();

		pose.translate(screen.field_22789 / 2.0f, screen.field_22790 / 2.0f, 0);
		pose.scale((float) scale, (float) scale, 1);
		pose.translate(-x, -z, 0);

		float mouseX = mX - screen.field_22789 / 2.0f;
		float mouseY = mY - screen.field_22790 / 2.0f;
		mouseX /= scale;
		mouseY /= scale;
		mouseX += x;
		mouseY += z;

		Rect2i bounds =
			new Rect2i(Mth.floor(-screen.field_22789 / 2.0f / scale + x), Mth.floor(-screen.field_22790 / 2.0f / scale + z),
				Mth.floor(screen.field_22789 / scale), Mth.floor(screen.field_22790 / scale));

		List<FormattedText> tooltip =
			TrainMapManager.renderAndPick(graphics, Mth.floor(mouseX), Mth.floor(mouseY), pt, false, bounds);

		pose.popPose();

		if (!renderToggleWidgetAndTooltip(graphics, screen, mX, mY) && tooltip != null)
			RemovedGuiUtils.drawHoveringText(graphics, tooltip, mX, mY, screen.field_22789, screen.field_22790, 256, mc.font);
	}

	private static boolean renderToggleWidgetAndTooltip(GuiGraphics graphics, Fullscreen screen, int mouseX,
		int mouseY) {
		TrainMapManager.renderToggleWidget(graphics, 3, 30);
		if (!TrainMapManager.isToggleWidgetHovered(mouseX, mouseY, 3, 30))
			return false;

		RemovedGuiUtils.drawHoveringText(graphics, List.of(CreateLang.translate("train_map.toggle")
			.component()), mouseX, mouseY + 20, screen.field_22789, screen.field_22790, 256, Minecraft.getInstance().font);
		return true;
	}

}
