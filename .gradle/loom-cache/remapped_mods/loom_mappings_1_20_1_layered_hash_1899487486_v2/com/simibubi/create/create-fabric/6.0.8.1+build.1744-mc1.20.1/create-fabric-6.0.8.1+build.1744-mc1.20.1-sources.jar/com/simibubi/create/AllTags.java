package com.simibubi.create;

import static com.simibubi.create.AllTags.NameSpace.FORGE;
import static com.simibubi.create.AllTags.NameSpace.MOD;
import static com.simibubi.create.AllTags.NameSpace.QUARK;
import static com.simibubi.create.AllTags.NameSpace.TIC;
import static com.simibubi.create.AllTags.NameSpace.TRINKETS;

import org.jetbrains.annotations.ApiStatus.ScheduledForRemoval;
import org.jetbrains.annotations.Nullable;

import com.simibubi.create.api.contraption.ContraptionType;
import com.simibubi.create.api.contraption.storage.item.MountedItemStorage;
import com.simibubi.create.api.contraption.storage.item.MountedItemStorageType;
import com.simibubi.create.api.registry.CreateRegistries;
import com.simibubi.create.content.decoration.palettes.AllPaletteStoneTypes;
import com.simibubi.create.foundation.data.recipe.CommonMetal;

import net.createmod.catnip.lang.Lang;
import net.minecraft.core.Registry;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.core.registries.Registries;
import net.minecraft.resources.ResourceKey;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.tags.TagKey;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.item.BlockItem;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.crafting.RecipeSerializer;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.material.Fluid;
import net.minecraft.world.level.material.FluidState;

public class AllTags {
	@ScheduledForRemoval(inVersion = "1.21.1+ Port")
	@Deprecated(since = "6.0.7", forRemoval = true)
	public static <T> TagKey<T> optionalTag(Registry<T> registry,
											ResourceLocation id) {
		return TagKey.create(registry.key(), id);
	}

	@ScheduledForRemoval(inVersion = "1.21.1+ Port")
	@Deprecated(since = "6.0.7", forRemoval = true)
	public static <T> TagKey<T> forgeTag(Registry<T> registry, String path) {
		return optionalTag(registry, FORGE.id(path));
	}

	@ScheduledForRemoval(inVersion = "1.21.1+ Port")
	@Deprecated(since = "6.0.7", forRemoval = true)
	public static TagKey<Block> forgeBlockTag(String path) {
		return forgeTag(BuiltInRegistries.BLOCK, path);
	}

	@ScheduledForRemoval(inVersion = "1.21.1+ Port")
	@Deprecated(since = "6.0.7", forRemoval = true)
	public static TagKey<Item> forgeItemTag(String path) {
		return forgeTag(BuiltInRegistries.ITEM, path);
	}

	@ScheduledForRemoval(inVersion = "1.21.1+ Port")
	@Deprecated(since = "6.0.7", forRemoval = true)
	public static TagKey<Fluid> forgeFluidTag(String path) {
		return forgeTag(BuiltInRegistries.FLUID, path);
	}

	public enum NameSpace {

		MOD(Create.ID),
		FORGE("c"),
		TIC("tconstruct"),
		QUARK("quark"),
		GS("galosphere"),
		// fabric: Trinkets compat is used instead
		CURIOS("curios"),
		TRINKETS("trinkets");

		public final String id;

		NameSpace(String id) {
			this.id = id;
		}

		public ResourceLocation id(String path) {
			return new ResourceLocation(this.id, path);
		}

		public ResourceLocation id(Enum<?> entry, @Nullable String pathOverride) {
			return this.id(pathOverride != null ? pathOverride : Lang.asId(entry.name()));
		}
	}

	public enum AllBlockTags {

		BRITTLE,
		CASING,
		COPYCAT_ALLOW,
		COPYCAT_DENY,
		FAN_PROCESSING_CATALYSTS_BLASTING(MOD, "fan_processing_catalysts/blasting"),
		FAN_PROCESSING_CATALYSTS_HAUNTING(MOD, "fan_processing_catalysts/haunting"),
		FAN_PROCESSING_CATALYSTS_SMOKING(MOD, "fan_processing_catalysts/smoking"),
		FAN_PROCESSING_CATALYSTS_SPLASHING(MOD, "fan_processing_catalysts/splashing"),
		FAN_TRANSPARENT,
		GIRDABLE_TRACKS,
		MOVABLE_EMPTY_COLLIDER,
		NON_MOVABLE,
		NON_BREAKABLE,
		PASSIVE_BOILER_HEATERS,
		SAFE_NBT,
		SEATS,
		POSTBOXES,
		TABLE_CLOTHS,
		TOOLBOXES,
		TRACKS,
		TREE_ATTACHMENTS,
		VALVE_HANDLES,
		WINDMILL_SAILS,
		WRENCH_PICKUP,
		CHEST_MOUNTED_STORAGE,
		SIMPLE_MOUNTED_STORAGE,
		ROOTS,
		SUGAR_CANE_VARIANTS,
		NON_HARVESTABLE,
		SINGLE_BLOCK_INVENTORIES,
		CARDBOARD_STORAGE_BLOCKS(FORGE, "cardboard_blocks"),
		ANDESITE_ALLOY_STORAGE_BLOCKS(FORGE, "andesite_alloy_blocks"),

		STONE_ORES_IN_GROUND(FORGE, "stone_ores_in_ground"),
		DEEPSLATE_ORES_IN_GROUND(FORGE, "deepslate_ores_in_ground"),

		CORALS,

		RELOCATION_NOT_SUPPORTED(FORGE),

		SLIMY_LOGS(TIC),
		NON_DOUBLE_DOOR(QUARK),

		;

		public final TagKey<Block> tag;

		AllBlockTags() {
			this(MOD);
		}

		AllBlockTags(NameSpace namespace) {
			this(namespace, null);
		}

		AllBlockTags(NameSpace namespace, @Nullable String pathOverride) {
			this.tag = TagKey.create(Registries.BLOCK, namespace.id(this, pathOverride));
		}

		@SuppressWarnings("deprecation")
		public boolean matches(Block block) {
			return block.builtInRegistryHolder()
				.is(tag);
		}

		public boolean matches(ItemStack stack) {
			return stack != null && stack.getItem() instanceof BlockItem blockItem && matches(blockItem.getBlock());
		}

		public boolean matches(BlockState state) {
			return state.is(tag);
		}

	}

	/**
	 * Despite the name, not truly all item tags.
	 *
	 * @see CommonMetal
	 * @see AllPaletteStoneTypes#materialTag
	 */
	public enum AllItemTags {

		BLAZE_BURNER_FUEL_REGULAR(MOD, "blaze_burner_fuel/regular"),
		BLAZE_BURNER_FUEL_SPECIAL(MOD, "blaze_burner_fuel/special"),
		CASING,
		CONTRAPTION_CONTROLLED,
		CREATE_INGOTS,
		CRUSHED_RAW_MATERIALS,
		INVALID_FOR_TRACK_PAVING,
		DEPLOYABLE_DRINK,
		MODDED_STRIPPED_LOGS,
		MODDED_STRIPPED_WOOD,
		PRESSURIZED_AIR_SOURCES,
		SANDPAPER,
		SEATS,
		POSTBOXES,
		TABLE_CLOTHS,
		DYED_TABLE_CLOTHS,
		PULPIFIABLE,
		SLEEPERS,
		TOOLBOXES,
		PACKAGES,
		CHAIN_RIDEABLE,
		TRACKS,
		UPRIGHT_ON_BELT,
		NOT_UPRIGHT_ON_BELT,
		NOT_POTION,
		VALVE_HANDLES,
		VANILLA_STRIPPED_LOGS,
		VANILLA_STRIPPED_WOOD,
		DISPENSE_BEHAVIOR_WRAP_BLACKLIST,

		STRIPPED_LOGS(FORGE),
		STRIPPED_WOOD(FORGE),

		OBSIDIAN_DUST(FORGE, "obsidian_dusts"),

		PLATES(FORGE),
		OBSIDIAN_PLATES(FORGE, "obsidian_plates"),
		CARDBOARD_PLATES(FORGE, "cardboard_plates"),

		WRENCH(FORGE, "wrenches"),

		ALLURITE(MOD, "stone_types/galosphere/allurite"),
		AMETHYST(MOD, "stone_types/galosphere/amethyst"),
		LUMIERE(MOD, "stone_types/galosphere/lumiere"),

		CERTUS_QUARTZ(FORGE, "certus_quartz/gems"),

		AMETRINE_ORES(FORGE, "ametrine_ores"),
		ANTHRACITE_ORES(FORGE, "anthracite_ores"),
		EMERALDITE_ORES(FORGE, "emeraldite_ores"),
		LIGNITE_ORES(FORGE, "lignite_ores"),

		RAW_MATERIALS(FORGE),
		CARDBOARD_STORAGE_BLOCKS(FORGE, "cardboard_blocks"),
		ANDESITE_ALLOY_STORAGE_BLOCKS(FORGE, "andesite_alloy_blocks"),

		STONE_ORES_IN_GROUND(FORGE, "stone_ores_in_ground"),
		DEEPSLATE_ORES_IN_GROUND(FORGE, "deepslate_ores_in_ground"),

		HONEY_BUCKETS(FORGE, "honey_buckets"),

		FLOUR(FORGE),
		WHEAT_FLOUR(FORGE, "wheat_flour"),

		DOUGH(FORGE),
		WHEAT_DOUGH(FORGE, "wheat_dough"),

		HELMET_ARMORS(FORGE, "helmets"),
		CHESTPLATE_ARMORS(FORGE, "chestplates"),
		LEGGING_ARMORS(FORGE, "leggings"),
		BOOT_ARMORS(FORGE, "boots"),

		UA_CORAL(MOD, "upgrade_aquatic/coral"),
		// fabric: Trinkets compat is used instead
		//CURIOS_HEAD(CURIOS, "head"),
		TRINKETS_FACE(TRINKETS, "head/face");

		public final TagKey<Item> tag;

		AllItemTags() {
			this(MOD);
		}

		AllItemTags(NameSpace namespace) {
			this(namespace, null);
		}

		AllItemTags(NameSpace namespace, @Nullable String pathOverride) {
			this.tag = TagKey.create(Registries.ITEM, namespace.id(this, pathOverride));
		}

		@SuppressWarnings("deprecation")
		public boolean matches(Item item) {
			return item.builtInRegistryHolder()
				.is(tag);
		}

		public boolean matches(ItemStack stack) {
			return stack.is(tag);
		}

	}

	public enum AllFluidTags {

		BOTTOMLESS_ALLOW(MOD, "bottomless/allow"),
		BOTTOMLESS_DENY(MOD, "bottomless/deny"),
		FAN_PROCESSING_CATALYSTS_BLASTING(MOD, "fan_processing_catalysts/blasting"),
		FAN_PROCESSING_CATALYSTS_HAUNTING(MOD, "fan_processing_catalysts/haunting"),
		FAN_PROCESSING_CATALYSTS_SMOKING(MOD, "fan_processing_catalysts/smoking"),
		FAN_PROCESSING_CATALYSTS_SPLASHING(MOD, "fan_processing_catalysts/splashing"),

		// fabric: extra tag for diving helmet behavior
		DIVING_FLUIDS,

		// fabric: this is used to avoid rendering the on-screen water overlay when submerged in Create's fluids
		CREATE_FLUIDS,

		TEA(FORGE),
		HONEY(FORGE),
		CHOCOLATE(FORGE),

		CREOSOTE(FORGE);

		public final TagKey<Fluid> tag;

		AllFluidTags() {
			this(MOD);
		}

		AllFluidTags(NameSpace namespace) {
			this(namespace, null);
		}

		AllFluidTags(NameSpace namespace, @Nullable String pathOverride) {
			this.tag = TagKey.create(Registries.FLUID, namespace.id(this, pathOverride));
		}

		@SuppressWarnings("deprecation")
		public boolean matches(Fluid fluid) {
			return fluid.is(tag);
		}

		public boolean matches(FluidState state) {
			return state.is(tag);
		}

	}

	public enum AllEntityTags {
		BLAZE_BURNER_CAPTURABLE,
		IGNORE_SEAT,

		;

		public final TagKey<EntityType<?>> tag;

		AllEntityTags() {
			this(MOD);
		}

		AllEntityTags(NameSpace namespace) {
			this(namespace, null);
		}

		AllEntityTags(NameSpace namespace, @Nullable String pathOverride) {
			this.tag = TagKey.create(Registries.ENTITY_TYPE, namespace.id(this, pathOverride));
		}

		public boolean matches(EntityType<?> type) {
			return type.is(tag);
		}

		public boolean matches(Entity entity) {
			return matches(entity.getType());
		}

	}

	public enum AllRecipeSerializerTags {

		AUTOMATION_IGNORE,

		;

		public final TagKey<RecipeSerializer<?>> tag;

		AllRecipeSerializerTags() {
			this(MOD);
		}

		AllRecipeSerializerTags(NameSpace namespace) {
			this(namespace, null);
		}

		AllRecipeSerializerTags(NameSpace namespace, @Nullable String pathOverride) {
			this.tag = TagKey.create(Registries.RECIPE_SERIALIZER, namespace.id(this, pathOverride));
		}

		public boolean matches(RecipeSerializer<?> recipeSerializer) {
			ResourceKey<RecipeSerializer<?>> key = BuiltInRegistries.RECIPE_SERIALIZER.getResourceKey(recipeSerializer).orElseThrow();
			return BuiltInRegistries.RECIPE_SERIALIZER.getHolder(key).orElseThrow().is(tag);
		}

	}

	public enum AllContraptionTypeTags {
		OPENS_CONTROLS,
		REQUIRES_VEHICLE_FOR_RENDER;

		public final TagKey<ContraptionType> tag;

		AllContraptionTypeTags() {
			this(MOD);
		}

		AllContraptionTypeTags(NameSpace namespace) {
			this(namespace, null);
		}

		AllContraptionTypeTags(NameSpace namespace, @Nullable String pathOverride) {
			this.tag = TagKey.create(CreateRegistries.CONTRAPTION_TYPE, namespace.id(this, pathOverride));
		}

		public boolean matches(ContraptionType type) {
			return type.is(this.tag);
		}

	}

	public enum AllMountedItemStorageTypeTags {
		INTERNAL,
		FUEL_BLACKLIST;

		public final TagKey<MountedItemStorageType<?>> tag;

		AllMountedItemStorageTypeTags() {
			this(MOD);
		}

		AllMountedItemStorageTypeTags(NameSpace namespace) {
			this(namespace, null);
		}

		AllMountedItemStorageTypeTags(NameSpace namespace, @Nullable String pathOverride) {
			this.tag = TagKey.create(CreateRegistries.MOUNTED_ITEM_STORAGE_TYPE, namespace.id(this, pathOverride));
		}

		public boolean matches(MountedItemStorage storage) {
			return this.matches(storage.type);
		}

		public boolean matches(MountedItemStorageType<?> type) {
			return type.is(this.tag);
		}

	}

}
