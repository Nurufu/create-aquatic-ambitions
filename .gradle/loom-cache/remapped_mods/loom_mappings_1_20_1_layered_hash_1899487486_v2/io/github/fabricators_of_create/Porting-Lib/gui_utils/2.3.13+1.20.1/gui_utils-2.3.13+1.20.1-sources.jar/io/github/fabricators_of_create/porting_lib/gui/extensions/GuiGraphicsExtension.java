package io.github.fabricators_of_create.porting_lib.gui.extensions;

import java.util.List;
import net.minecraft.client.gui.Font;
import net.minecraft.network.chat.FormattedText;
import net.minecraft.world.item.ItemStack;

public interface GuiGraphicsExtension {
	default void renderComponentTooltip(Font font, List<? extends FormattedText> tooltips, int mouseX, int mouseY, ItemStack stack) {
		throw new RuntimeException("Mixin failed!");
	}
}
