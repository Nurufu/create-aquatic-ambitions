@ParametersAreNonnullByDefault
@MethodsReturnNonnullByDefault
package mezz.jei.library.ingredients.subtypes;

import javax.annotation.ParametersAreNonnullByDefault;
