@ParametersAreNonnullByDefault
@MethodsReturnNonnullByDefault
package mezz.jei;

import javax.annotation.ParametersAreNonnullByDefault;
