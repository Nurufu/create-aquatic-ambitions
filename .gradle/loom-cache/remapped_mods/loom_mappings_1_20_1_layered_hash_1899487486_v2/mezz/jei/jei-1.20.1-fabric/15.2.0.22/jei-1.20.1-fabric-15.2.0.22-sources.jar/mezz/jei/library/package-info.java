@ParametersAreNonnullByDefault
@MethodsReturnNonnullByDefault
package mezz.jei.library;

import javax.annotation.ParametersAreNonnullByDefault;
