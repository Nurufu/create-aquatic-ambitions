@ParametersAreNonnullByDefault
@MethodsReturnNonnullByDefault
package mezz.jei.library.color;

import javax.annotation.ParametersAreNonnullByDefault;
