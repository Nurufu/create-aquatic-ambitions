@ParametersAreNonnullByDefault
@MethodsReturnNonnullByDefault
package mezz.jei.api.ingredients.subtypes;

import javax.annotation.ParametersAreNonnullByDefault;
