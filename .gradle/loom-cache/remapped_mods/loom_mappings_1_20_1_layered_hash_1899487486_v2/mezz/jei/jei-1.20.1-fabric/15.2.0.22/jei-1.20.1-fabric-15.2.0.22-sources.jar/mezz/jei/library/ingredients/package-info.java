@ParametersAreNonnullByDefault
@MethodsReturnNonnullByDefault
package mezz.jei.library.ingredients;

import javax.annotation.ParametersAreNonnullByDefault;
