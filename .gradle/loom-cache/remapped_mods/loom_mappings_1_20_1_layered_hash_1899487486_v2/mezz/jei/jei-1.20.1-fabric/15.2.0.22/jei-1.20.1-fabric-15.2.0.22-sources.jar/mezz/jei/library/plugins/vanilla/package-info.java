@ParametersAreNonnullByDefault
@MethodsReturnNonnullByDefault
package mezz.jei.library.plugins.vanilla;

import javax.annotation.ParametersAreNonnullByDefault;
