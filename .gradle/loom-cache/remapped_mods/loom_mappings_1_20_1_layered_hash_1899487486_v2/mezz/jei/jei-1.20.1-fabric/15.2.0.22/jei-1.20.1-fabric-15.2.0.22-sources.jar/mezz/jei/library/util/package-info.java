@ParametersAreNonnullByDefault
@MethodsReturnNonnullByDefault
package mezz.jei.library.util;

import javax.annotation.ParametersAreNonnullByDefault;
