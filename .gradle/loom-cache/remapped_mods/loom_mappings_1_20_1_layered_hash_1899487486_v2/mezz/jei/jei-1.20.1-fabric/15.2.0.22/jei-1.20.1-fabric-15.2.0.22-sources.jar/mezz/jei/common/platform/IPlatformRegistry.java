package mezz.jei.common.platform;

import java.util.Optional;
import java.util.stream.Stream;
import net.minecraft.resources.ResourceLocation;

public interface IPlatformRegistry<T> {
    Stream<T> getValues();

    Optional<T> getValue(ResourceLocation resourceLocation);

    int getId(T entry);

    Optional<T> getValue(int id);

    boolean contains(T entry);

    Optional<ResourceLocation> getRegistryName(T entry);
}
