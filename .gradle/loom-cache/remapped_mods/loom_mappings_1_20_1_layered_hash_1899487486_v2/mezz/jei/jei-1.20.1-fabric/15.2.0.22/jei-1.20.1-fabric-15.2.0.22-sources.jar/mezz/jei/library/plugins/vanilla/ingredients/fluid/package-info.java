@ParametersAreNonnullByDefault
@MethodsReturnNonnullByDefault
package mezz.jei.library.plugins.vanilla.ingredients.fluid;

import javax.annotation.ParametersAreNonnullByDefault;
