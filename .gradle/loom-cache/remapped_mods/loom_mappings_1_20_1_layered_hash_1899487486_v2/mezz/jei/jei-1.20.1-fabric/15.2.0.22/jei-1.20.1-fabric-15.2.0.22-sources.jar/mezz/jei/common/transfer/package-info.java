@ParametersAreNonnullByDefault
@MethodsReturnNonnullByDefault
package mezz.jei.common.transfer;

import javax.annotation.ParametersAreNonnullByDefault;
