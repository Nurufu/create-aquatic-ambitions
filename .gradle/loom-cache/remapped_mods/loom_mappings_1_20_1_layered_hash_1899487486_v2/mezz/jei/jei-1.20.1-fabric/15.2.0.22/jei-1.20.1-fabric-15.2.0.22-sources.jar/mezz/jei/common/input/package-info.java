@ParametersAreNonnullByDefault
@MethodsReturnNonnullByDefault
package mezz.jei.common.input;

import javax.annotation.ParametersAreNonnullByDefault;
