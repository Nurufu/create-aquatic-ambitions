@ParametersAreNonnullByDefault
@MethodsReturnNonnullByDefault
package mezz.jei.common.platform;

import javax.annotation.ParametersAreNonnullByDefault;
