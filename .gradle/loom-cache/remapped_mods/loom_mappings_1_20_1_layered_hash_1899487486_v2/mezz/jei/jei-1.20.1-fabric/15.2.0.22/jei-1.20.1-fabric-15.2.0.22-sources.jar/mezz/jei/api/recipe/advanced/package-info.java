@ParametersAreNonnullByDefault
@MethodsReturnNonnullByDefault
package mezz.jei.api.recipe.advanced;

import javax.annotation.ParametersAreNonnullByDefault;
