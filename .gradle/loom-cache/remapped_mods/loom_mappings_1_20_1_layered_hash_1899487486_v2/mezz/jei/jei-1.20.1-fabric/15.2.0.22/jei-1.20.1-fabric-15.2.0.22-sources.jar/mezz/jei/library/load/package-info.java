@ParametersAreNonnullByDefault
@MethodsReturnNonnullByDefault
package mezz.jei.library.load;

import javax.annotation.ParametersAreNonnullByDefault;
