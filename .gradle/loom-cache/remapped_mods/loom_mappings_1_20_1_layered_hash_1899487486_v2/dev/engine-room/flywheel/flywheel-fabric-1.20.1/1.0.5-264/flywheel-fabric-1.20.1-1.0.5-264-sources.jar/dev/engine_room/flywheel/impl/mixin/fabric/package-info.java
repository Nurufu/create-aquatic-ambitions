@ParametersAreNonnullByDefault
@FieldsAreNonnullByDefault
@MethodsReturnNonnullByDefault
package dev.engine_room.flywheel.impl.mixin.fabric;

import javax.annotation.ParametersAreNonnullByDefault;
