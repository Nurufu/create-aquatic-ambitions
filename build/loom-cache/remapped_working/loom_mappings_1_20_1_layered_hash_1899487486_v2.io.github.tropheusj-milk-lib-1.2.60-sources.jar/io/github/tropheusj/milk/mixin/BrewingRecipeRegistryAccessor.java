package io.github.tropheusj.milk.mixin;

import net.minecraft.world.item.Item;
import net.minecraft.world.item.alchemy.PotionBrewing;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Invoker;

@Mixin(PotionBrewing.class)
public interface BrewingRecipeRegistryAccessor {
	@Invoker("registerPotionType")
	static void milk$registerPotionType(Item item) {
		throw new RuntimeException("Mixin application failed!");
	}

	@Invoker("registerItemRecipe")
	static void milk$registerItemRecipe(Item input, Item ingredient, Item output) {
		throw new RuntimeException("Mixin application failed!");
	}
}
